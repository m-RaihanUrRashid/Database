# Mental Health Database
This is a student project for the Database Management System course, Department of Computer Science and Engineering, Independent University, Bangladesh.

This web application aims to showcase the uses of relational database systems in real life; namely to help people find mental health resources.

# Team
- Showndorjo Dhara

- Nazifa Tasneem Chowdhury

- Ikram Hossain Akif

- Mohammad Gazi Mobasher

- Mohammad Raihan Ur Rashid

- Marcel Jupiter Gomes

_**Independent University, Bangladesh - Autumn 2023**_
