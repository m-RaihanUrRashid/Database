<?php $__env->startSection('title' , 'Appointment'); ?>
<?php $__env->startSection('content'); ?>

<style>
    .parent {
        margin: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }

    .clickable-row:hover {
        background-color: red;
        cursor: pointer;
    }

    .clickable-row.selected {
        background-color: #c0c0c0;
    }

    .table-hover tbody tr:hover td {
        background: #E6F7FF;
    }

    .table-hover tbody tr.selected td {
        background: #3498db;

    }

    .btn {
        padding: 10px;
        font-size: 14px;
        background-color: #3498db;
        color: #fff;
        border: none;
        cursor: pointer;
        border-radius: 4px;
    }
</style>

<button class="load" onclick="goHome()" style="position: absolute; left: 0; top: 0; margin: 30px;">Back to Home Page</button>


<?php if(session()->has('success')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="parent">
    <div class="d-flex justify-content-center">
        <table class="table table-hover" id="specialistid" style="width: 70%; table-layout: fixed; border-collapse: collapse;">
            <thead style="background-color: #3366CC; color: #fff; border-bottom: 2px solid lightblue;">
                <tr>
                    <th style="padding: 6px;">Specialist ID</th>
                    <th style="padding: 6px;width: 200px;">Name</th>
                    <th style="padding: 6px;">Type</th>
                    <th style="padding: 6px; width: 150px;">Location</th>
                    <th style="padding: 6px;">Date</th>
                    <th style="padding: 6px;">Time</th>
                    <th style="padding: 6px;"></th>

                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="clickable-row" onclick="markAsDone(1)" style="margin: 10px; background-color: #fff; border-bottom: 1px solid lightgrey;">
                    <td><?php echo e($app->csUserID); ?></td>

                    <td>
                        <?php if($app->specialist): ?>
                        <?php echo e($app->specialist->person ? $app->specialist->person->cFname.' '.$app->specialist->person->cLname : 'No Specialist Information'); ?></p>
                        <?php else: ?>
                        No Specialist Assigned
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($app->specialist->cType); ?></td>

                    <td><?php echo e($app->specialist->cOff_Address); ?></td>
                    <td><?php echo e($app->dappDate); ?></td>
                    <td><?php echo e($app->cappTime); ?></td>
                    <td>
                        <form method="post" action="<?php echo e(route('destroy.app', [
                                    'cpUserID' => $app->cpUserID,
                                    'csUserID' => $app->csUserID,
                                    'dappDate' => $app->dappDate,
                                    'cappTime' => $app->cappTime,
                                ])); ?>" style="margin-top: 5px;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button onclick="t(this)" class="btn" type="submit" name="delete">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- </form> -->
</div>

<script>
    function t() {
        console.log(this);
    }

    function goHome() {
        window.location.href = "/patientHome";
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Uni\Courses\CSE303 - Database Management\Project\Database\resources\views/patientCheckApp.blade.php ENDPATH**/ ?>